//
//  StringExtension.swift
//  AlamofireDemo
//
//  Created by Trinh Minh Cuong on 10/25/14.
//  Copyright (c) 2014 Techmaster Vietnam. All rights reserved.
//

import Foundation
extension String {
    static func generateRandomName() -> String {
        let firstNames = ["Michael", "Christopher", "Joshua", "Matthew", "Daniel", "David", "Andrew","Justin","Ryan","Robert", "James","Nicholas", "Joseph", "John", "Jonathan", "Kevin", "Kyle","Brandon", "William", "Eric", "Jose", "Steven","Jacob","Brian","Tyler","Zachary","Aaron","Alexander","Adam","Thomas","Richard","Timothy","Benjamin","Jason","Jeffrey","Sean","Jordan","Jeremy","Travis","Cody","Nathan","Mark","Jesse","Charles","Juan","Samuel","Patrick","Dustin","Scott","Stephen","Paul","Bryan","Luis","Derek","Austin","Kenneth","Carlos","Gregory","Alex","Cameron","Jared","Jesus","Bradley","Christian","Corey","Victor","Cory","Miguel","Tylor","Edward","Francisco","Trevor","Adrian","Jorge","Ian","Antonio","Shawn","Ricardo","Vincent","Edgar","Erik","Peter","Shane","Evan","Chad","Alejandro","Brett","Gabriel","Eduardo","Raymond","Phillip","Mario","Marcus","Manuel","George","Martin","Spencer","Garrett","Casey"]
        
        let lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "García", "Rodríguez", "Wilson", "Martínez", "Anderson", "Taylor", "Thomas", "Hernández", "Moore", "Martin", "Jackson", "Thompson"]
        let firstIndex = Int(arc4random_uniform(UInt32(firstNames.count)))
        let lastIndex = Int(arc4random_uniform(UInt32(lastNames.count)))
        return "\(firstNames[firstIndex]) \(lastNames[lastIndex])"
    }
}