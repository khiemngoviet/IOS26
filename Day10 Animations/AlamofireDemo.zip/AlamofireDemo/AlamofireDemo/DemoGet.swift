//
//  DemoGet.swift
//  AlamofireDemo
//
//  Created by Trinh Minh Cuong on 10/25/14.
//  Copyright (c) 2014 Techmaster Vietnam. All rights reserved.
//

import UIKit
import Alamofire

class DemoGet: ConsoleScreen {

    override func viewDidLoad() {
        super.viewDidLoad()
        let URL = "http://audiogara.com/index/get"
        Alamofire.request(.GET, URL).responseJSON { (request, response, json, error) in
            println(json!)
        }
        
        Alamofire.request(.GET, URL).responseJSON { (_, _, json, _) in
            println(json!)
        }
        /*
        Similar code in Objective-C
        NSURL *baseURL = [[NSURL alloc] initWithString:BASE_URL];
        _httpRequestOperationManager = [[AFHTTPRequestOperationManager alloc]initWithBaseURL:baseURL];
        [_httpRequestOperationManager GET:@"/index/get" parameters:nil
            success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"%@", responseObject);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"%@", [error description]);
        }];
        */

    }



}
