//
//  GetWithParam.swift
//  AlamofireDemo
//
//  Created by Trinh Minh Cuong on 10/25/14.
//  Copyright (c) 2014 Techmaster Vietnam. All rights reserved.
//

import UIKit
import Alamofire
class GetWithParam: ConsoleScreen {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let URL = "http://audiogara.com/index/addproduct"
        let price = NSNumber(unsignedInt: arc4random_uniform(1000))
        
        Alamofire.request(.POST, URL, parameters: ["name": String.generateRandomName(), "unitprice": price], encoding: ParameterEncoding.JSON).responseJSON { (request, response, json, error) in
            println(json!)
        }
        
        
    }


}
